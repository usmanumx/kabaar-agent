import subprocess
import time
import urllib.request
import urllib.error
import json
import sys
import os

def run_test():
    # Start the server as a subprocess
    # Add workspace root to python path
    env = os.environ.copy()
    env["PYTHONPATH"] = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    server_path = os.path.join("backend", "server.py")
    print(f"Starting backend server: {server_path}")
    server_proc = subprocess.Popen(
        [sys.executable, server_path],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    
    # Wait for the server to spin up
    time.sleep(3)
    
    url = "http://localhost:8000/api/pipeline"
    payload = {
        "description": "5kg copper wires aur purani copper tonti, baqi loha hai",
        "latitude": 33.60,
        "longitude": 73.06
    }
    
    headers = {"Content-Type": "application/json"}
    data = json.dumps(payload).encode("utf-8")
    
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    
    try:
        print("Sending pipeline request...")
        with urllib.request.urlopen(req, timeout=10) as response:
            resp_data = response.read().decode("utf-8")
            result = json.loads(resp_data)
            print("PIPELINE TEST SUCCESSFUL!")
            print("Response Payload:")
            print(json.dumps(result, indent=2))
            
            # Check for expected keys
            assert "transaction_id" in result
            assert "items" in result
            assert "valuation" in result
            assert "optimal_yard" in result
            assert "justification_log" in result
            assert "receipt" in result
            assert "execution_trace" in result
            
            print("\nVerification of logs and ledger...")
            # Check payout_ledger.json exists and is populated
            ledger_file = os.path.join("backend", "ops", "payout_ledger.json")
            if os.path.exists(ledger_file):
                print(f"Ledger file exists at {ledger_file}.")
                with open(ledger_file, "r") as lf:
                    ledger = json.load(lf)
                    print(f"Total transactions committed in ledger: {len(ledger)}")
            else:
                print("ERROR: Ledger file was not created!")
                
            # Check execution_trace.log
            trace_file = os.path.join("backend", "execution_trace.log")
            if os.path.exists(trace_file):
                print(f"Execution trace log exists at {trace_file}.")
            else:
                print("ERROR: Trace log file was not created!")
                
    except urllib.error.URLError as e:
        print(f"URLError connecting to server: {e}", file=sys.stderr)
        if server_proc.poll() is not None:
            # Server crashed, print stderr
            stdout, stderr = server_proc.communicate()
            print("Server process output:", file=sys.stderr)
            print("STDOUT:\n", stdout, file=sys.stderr)
            print("STDERR:\n", stderr, file=sys.stderr)
    except AssertionError as e:
        print(f"Assertion failed: {e}", file=sys.stderr)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
    finally:
        print("Shutting down backend server...")
        server_proc.terminate()
        server_proc.wait()
        print("Server shutdown complete.")

if __name__ == "__main__":
    run_test()
