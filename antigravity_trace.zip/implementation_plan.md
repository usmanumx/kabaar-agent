# KabaarAgent: Visual Appraisal & Trading Engine

KabaarAgent is a visual appraisal and trading engine designed for informal scrap collectors. It leverages Google Antigravity and Gemini 3.5 Flash to process multilingual text or image inputs, assess material type, weight, and purity, match against local commodity index rates, commit transactions to a local ledger, and display live execution reasoning traces.

This plan details the full-stack system architecture, integration blueprint, and step-by-step parallel implementation task list.

## User Review Required

> [!IMPORTANT]
> The backend services will run as a Python FastAPI application in the background of the workspace. The Android Jetpack Compose app will connect to this server (usually via `http://10.0.2.2:8000` when running on the Android Emulator).
> 
> We will seed the commodity market rates in `backend/arbitrage/market_rates.json` with the required yards: Rawalpindi Industrial Recycling Hub and Saddar Scrap Foundry.
>
> We will configure the Appraiser Agent to use Gemini 3.5 Flash for visual/text description extraction. We'll write a Python appraiser script utilizing Google GenAI API or standard generative models with a robust fallback mock mechanism for testing without live API keys.

## Open Questions

> [!WARNING]
> Do you have a specific Gemini API key or Google Cloud Project configured for Gemini 3.5 Flash? If not, we will default to using a mock appraiser extractor that simulates Gemini 3.5 Flash parsing, which can be easily swapped for a live API call by setting the `GEMINI_API_KEY` environment variable.

## Proposed Changes

We will organize the workspace into `backend` and `android` directories.

### Integration Blueprint

#### [NEW] [antigravity.json](file:///c:/Projects/kabaarAgent/antigravity.json)
Defines the pipeline graph execution sequence.

---

### Backend Components

#### [NEW] [appraiser.py](file:///c:/Projects/kabaarAgent/backend/appraiser/appraiser.py)
Implements Sub-Agent 1 (The Appraiser Agent). Accepts text or base64 images and extracts:
- `material_type` (Copper, Iron, Aluminum, Cardboard)
- `estimated_weight_kg`
- `purity_grade` (High, Medium, Low)

#### [NEW] [market_rates.json](file:///c:/Projects/kabaarAgent/backend/arbitrage/market_rates.json)
Seed market rates database with the requested recycling yards.

#### [NEW] [arbitrage.py](file:///c:/Projects/kabaarAgent/backend/arbitrage/arbitrage.py)
Implements Sub-Agent 2 (The Arbitrage Agent). Calculates payouts and evaluates the optimal recycling yard. Outputs a negotiation justification log.

#### [NEW] [ops.py](file:///c:/Projects/kabaarAgent/backend/ops/ops.py)
Implements Sub-Agent 3 (The Operations Agent). Signs off on transactions, commits to `payout_ledger.json`, and outputs logistics pickup receipts.

#### [NEW] [payout_ledger.json](file:///c:/Projects/kabaarAgent/backend/ops/payout_ledger.json)
Ledger file to record transaction states.

#### [NEW] [server.py](file:///c:/Projects/kabaarAgent/backend/server.py)
A lightweight FastAPI server exposed at `localhost:8000` to orchestrate the pipeline and stream execution logs to the frontend.

---

### Frontend Components (Android)

#### [NEW] [android](file:///c:/Projects/kabaarAgent/android)
Jetpack Compose-based application structure created using the Android CLI tool. The app features:
- Live Camera & Voice input controls.
- Dynamic list displaying appraisal breakdown.
- Estimated valuation banner.
- Execution logs console pane (connected to backend server log stream).

---

## Verification Plan

### Automated Tests
- Python unit tests running `pytest` to verify appraiser, arbitrage, and operations modules.
- Verification of FastAPI endpoints using curl commands.

### Manual Verification
- Deploying the app on the running Android Emulator (`Pixel_6`).
- Injecting image/voice test payloads and verifying the live updating list, valuation banner, and terminal pane logs.
